#ifndef MESH_H
#define MESH_H


#define GLEW_STATIC
#include <GL/glew.h>

#include <iostream>
#include <vector>

class Mesh
{
    public:
        Mesh(std::vector<GLfloat> vertices, std::vector<GLuint> indices);
        virtual ~Mesh();
        void render();
        inline std::vector<GLfloat> getVertices() const { return m_Vertices; };
        inline std::vector<GLuint> getIndices() const { return m_Indices; };
    protected:
    private:
        GLuint m_VertexArray;
        std::vector<GLfloat> m_Vertices;
        std::vector<GLuint> m_Indices;
};

#endif // MESH_H
